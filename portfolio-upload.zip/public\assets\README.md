# Place your CV PDF here

Copy your `Nadhir-Benhalima.pdf` file to this folder.

The portfolio website will automatically embed and display it.
